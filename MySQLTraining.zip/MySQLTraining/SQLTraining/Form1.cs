﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLTraining
{
    public partial class Form1 : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlConnection sqlConnectionMy = null;
        public Form1()
        {
            InitializeComponent();
        }

        

        private void INSERT_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand($"INSERT INTO [Students](Name,SirName,Birthday) VALUES(@Name,@SirName,@Birthday)",sqlConnectionMy);

            command.Parameters.AddWithValue("Name",textBox1.Text);
            command.Parameters.AddWithValue("SirName", textBox2.Text);
            command.Parameters.AddWithValue("Birthday", textBox3.Text);

            MessageBox.Show(command.ExecuteNonQuery().ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnectionMy = new SqlConnection(ConfigurationManager.ConnectionStrings["DBLink"].ConnectionString);
            sqlConnectionMy.Open();

            sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString);
            sqlConnection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Products", sqlConnection);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
            dataGridView2.DataSource = dataSet.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //"SELECT * FROM Products WHERE UnitPrice > 100"
            SqlDataAdapter adapter = new SqlDataAdapter
                (
                    textBox4.Text, sqlConnection
                );
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
            dataGridView1.DataSource = dataSet.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            SqlDataReader dataReader = null;
            try
            {
                SqlCommand command = new SqlCommand("SELECT ProductName, QuantityPerUnit, UnitPrice FROM Products", sqlConnection);
                dataReader=command.ExecuteReader();

                ListViewItem item = null;
                while( dataReader.Read() ) 
                {
                    item = new ListViewItem(new string[] 
                    { 
                        Convert.ToString(dataReader["ProductName"]), 
                        Convert.ToString(dataReader["QuantityPerUnit"]), 
                        Convert.ToString(dataReader["UnitPrice"]) 
                    });
                    listView1.Items.Add(item);
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if( dataReader != null && dataReader.IsClosed) 
                    dataReader.Close();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = $"ProductName LIKE '%{textBox5.Text}%'";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {    
            switch(comboBox1.SelectedIndex) 
            {
                case 0:
                    (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = $"UnitsInStock <=10";
                    break;

                case 1:
                    (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = $"UnitsInStock >10 AND UnitsInStock <=50";
                    break;
                    
                case 2:
                    (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = $"UnitsInStock >50 AND UnitsInStock <=1000";
                    break;
                case 3:
                    (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = "";
                    break;
            }
        }
    }
}
